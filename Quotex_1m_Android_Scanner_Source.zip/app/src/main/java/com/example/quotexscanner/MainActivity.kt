package com.example.quotexscanner
import android.app.Activity
import android.content.*
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.widget.*

class MainActivity:Activity(){
    private val request=101
    private lateinit var status:TextView;private lateinit var output:TextView;private lateinit var detail:TextView;private lateinit var pair:Spinner
    private val rx=object:BroadcastReceiver(){override fun onReceive(c:Context?,i:Intent?){if(i==null)return;output.text="${i.getStringExtra("signal")?: "WAIT"}\nBullish rule score: ${i.getIntExtra("bull",50)}% | Bearish: ${i.getIntExtra("bear",50)}%";detail.text=i.getStringArrayListExtra("details")?.joinToString("\n• ",prefix="• ")?: ""}}
    override fun onCreate(saved:Bundle?){super.onCreate(saved)
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(24,24,24,24)}
        pair=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,listOf("EUR/USD OTC","EUR/USD"))}
        status=TextView(this).apply{text="Status: stopped";textSize=16f};output=TextView(this).apply{text="WAIT";textSize=26f};detail=TextView(this).apply{text="Scan details will appear here."}
        val start=Button(this).apply{text="Start automatic screen scan"};val stop=Button(this).apply{text="Stop scanner"}
        box.addView(TextView(this).apply{text="Quotex 1-minute signal scanner";textSize=22f});box.addView(pair);box.addView(status);box.addView(start);box.addView(stop);box.addView(output);box.addView(detail)
        box.addView(TextView(this).apply{text="Prototype only. Select the matching pair and 1-minute chart in Quotex. Screen pixels are only approximated; no trades are placed.";textSize=14f})
        setContentView(ScrollView(this).apply{addView(box)})
        start.setOnClickListener{startActivityForResult((getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager).createScreenCaptureIntent(),request)}
        stop.setOnClickListener{stopService(Intent(this,CaptureService::class.java));status.text="Status: stopped"}
        val f=IntentFilter(CaptureService.ACTION_RESULT);if(android.os.Build.VERSION.SDK_INT>=33)registerReceiver(rx,f,RECEIVER_NOT_EXPORTED)else @Suppress("DEPRECATION") registerReceiver(rx,f)
    }
    @Deprecated("Deprecated")
    override fun onActivityResult(req:Int,res:Int,data:Intent?){super.onActivityResult(req,res,data);if(req==request&&res==RESULT_OK&&data!=null){val s=Intent(this,CaptureService::class.java).putExtra(CaptureService.EXTRA_CODE,res).putExtra(CaptureService.EXTRA_DATA,data);if(android.os.Build.VERSION.SDK_INT>=26)startForegroundService(s)else startService(s);status.text="Scanning • ${pair.selectedItem}"}else status.text="Capture permission not granted"}
    override fun onDestroy(){try{unregisterReceiver(rx)}catch(_:Exception){};super.onDestroy()}
}
