package com.example.quotexscanner
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

object TechnicalAnalysis {
    fun analyze(c:List<Candle>):ScanResult {
        if(c.size<30) return ScanResult("WAIT",50,50,listOf("Need at least 30 detected candles; keep chart visible."))
        val closes=c.map{it.close}; val e9=ema(closes,9); val e21=ema(closes,21); val r=rsi(closes,14)
        val last=c.last(); var bull=0; var bear=0; val notes=mutableListOf<String>()
        if(e9>e21){bull+=2;notes+="EMA 9 above EMA 21."}else{bear+=2;notes+="EMA 9 below EMA 21."}
        if(r>=55){bull+=2;notes+="RSI ${r.toInt()} above 55."}else if(r<=45){bear+=2;notes+="RSI ${r.toInt()} below 45."}else notes+="RSI ${r.toInt()} neutral."
        val range=max(1e-7,last.high-last.low); val body=abs(last.close-last.open)
        val lower=min(last.open,last.close)-last.low; val upper=last.high-max(last.open,last.close)
        if(last.bullish && body/range>.55){bull++;notes+="Strong bullish candle body."}
        if(!last.bullish && body/range>.55){bear++;notes+="Strong bearish candle body."}
        if(lower/range>.45){bull++;notes+="Long lower wick; possible rejection."}
        if(upper/range>.45){bear++;notes+="Long upper wick; possible rejection."}
        val recent=c.takeLast(12); val priorHigh=recent.dropLast(1).maxOf{it.high}; val priorLow=recent.dropLast(1).minOf{it.low}
        if(last.high>priorHigh && last.close<priorHigh){bear++;notes+="Possible buy-side liquidity sweep (heuristic)."}
        if(last.low<priorLow && last.close>priorLow){bull++;notes+="Possible sell-side liquidity sweep (heuristic)."}
        val n=c.lastIndex
        if(c[n].low>c[n-2].high){bull++;notes+="Possible bullish 3-candle FVG proxy."}
        if(c[n-2].low>c[n].high){bear++;notes+="Possible bearish 3-candle FVG proxy."}
        val sum=max(1,bull+bear); val bp=(bull*100.0/sum).toInt().coerceIn(0,100); val sp=100-bp
        val signal=when{bull>=bear+2->"CALL";bear>=bull+2->"PUT";else->"WAIT"}
        notes+="Bullish rule score $bp%; bearish rule score $sp% (not calibrated probabilities)."
        notes+="OB and ZigZag are not reliably detected in this prototype."
        return ScanResult(signal,bp,sp,notes)
    }
    private fun ema(v:List<Double>,p:Int):Double { val k=2.0/(p+1); var x=v.take(p).average(); for(a in v.drop(p)) x=a*k+x*(1-k); return x }
    private fun rsi(v:List<Double>,p:Int):Double { val d=v.zipWithNext{a,b->b-a}.takeLast(p); val g=d.filter{it>0}.sum()/p; val l=-d.filter{it<0}.sum()/p; if(l==0.0) return 100.0; val rs=g/l; return 100-100/(1+rs) }
}
