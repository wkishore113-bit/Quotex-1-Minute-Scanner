
package com.example.quotexscanner

import android.app.Activity
import android.content.*
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.*

class MainActivity : Activity() {

    private val captureRequest = 101
    private val overlayRequest = 102

    private lateinit var status: TextView
    private lateinit var output: TextView
    private lateinit var detail: TextView
    private lateinit var pair: Spinner

    private val rx = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            if (i == null) return

            output.text =
                "${i.getStringExtra("signal") ?: "WAIT"}\n" +
                "Bullish: ${i.getIntExtra("bull", 50)}% | " +
                "Bearish: ${i.getIntExtra("bear", 50)}%"

            detail.text = i.getStringArrayListExtra("details")
                ?.joinToString("\n• ", prefix = "• ") ?: ""
        }
    }

    override fun onCreate(saved: Bundle?) {
        super.onCreate(saved)

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
        }

        pair = Spinner(this).apply {
            adapter = ArrayAdapter(
                this@MainActivity,
                android.R.layout.simple_spinner_dropdown_item,
                listOf("EUR/USD OTC", "EUR/USD")
            )
        }

        status = TextView(this).apply {
            text = "Status: stopped"
            textSize = 16f
        }

        output = TextView(this).apply {
            text = "WAIT"
            textSize = 26f
        }

        detail = TextView(this).apply {
            text = "Scan details will appear here."
        }

        val start = Button(this).apply {
            text = "Start automatic screen scan"
        }

        val stop = Button(this).apply {
            text = "Stop scanner"
        }

        box.addView(TextView(this).apply {
            text = "Quotex 1-minute signal scanner"
            textSize = 22f
        })

        box.addView(pair)
        box.addView(status)
        box.addView(start)
        box.addView(stop)
        box.addView(output)
        box.addView(detail)

        box.addView(TextView(this).apply {
            text = "Experimental prototype. Use demo trading only. Signals are estimates, not guaranteed predictions."
            textSize = 14f
        })

        setContentView(ScrollView(this).apply {
            addView(box)
        })

        start.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                val permissionIntent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
                startActivityForResult(permissionIntent, overlayRequest)
            } else {
                requestScreenCapture()
            }
        }

        stop.setOnClickListener {
            stopService(Intent(this, CaptureService::class.java))
            stopService(Intent(this, OverlayService::class.java))
            status.text = "Status: stopped"
        }

        val filter = IntentFilter(CaptureService.ACTION_RESULT)

        if (android.os.Build.VERSION.SDK_INT >= 33) {
            registerReceiver(rx, filter, RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(rx, filter)
        }
    }

    private fun requestScreenCapture() {
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE)
            as MediaProjectionManager

        startActivityForResult(
            manager.createScreenCaptureIntent(),
            captureRequest
        )
    }

    @Deprecated("Deprecated")
    override fun onActivityResult(
        req: Int,
        res: Int,
        data: Intent?
    ) {
        super.onActivityResult(req, res, data)

        if (req == overlayRequest) {
            if (Settings.canDrawOverlays(this)) {
                status.text = "Overlay permission granted. Tap Start again."
            } else {
                status.text = "Overlay permission not granted."
            }
            return
        }

        if (req == captureRequest && res == RESULT_OK && data != null) {

            startService(Intent(this, OverlayService::class.java))

            val serviceIntent = Intent(this, CaptureService::class.java)
                .putExtra(CaptureService.EXTRA_CODE, res)
                .putExtra(CaptureService.EXTRA_DATA, data)

            if (android.os.Build.VERSION.SDK_INT >= 26) {
                startForegroundService(serviceIntent)
            } else {
                startService(serviceIntent)
            }

            status.text = "Scanning • ${pair.selectedItem}"

        } else if (req == captureRequest) {
            status.text = "Screen capture permission not granted."
        }
    }

    override fun onDestroy() {
        try {
            unregisterReceiver(rx)
        } catch (_: Exception) {
        }
        super.onDestroy()
    }
}
