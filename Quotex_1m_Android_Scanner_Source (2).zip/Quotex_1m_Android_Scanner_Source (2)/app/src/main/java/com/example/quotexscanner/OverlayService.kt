
package com.example.quotexscanner

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView

class OverlayService : Service() {

    private lateinit var windowManager: WindowManager
    private var panel: TextView? = null

    private val receiver = object : android.content.BroadcastReceiver() {
        override fun onReceive(context: android.content.Context?, intent: Intent?) {
            if (intent == null) return

            val signal = intent.getStringExtra("signal") ?: "WAIT"
            val bull = intent.getIntExtra("bull", 50)
            val bear = intent.getIntExtra("bear", 50)

            panel?.text = "QUOTEX SCANNER\n\n$signal\nBullish: $bull% | Bearish: $bear%"
            panel?.setTextColor(
                when (signal) {
                    "CALL" -> Color.GREEN
                    "PUT" -> Color.RED
                    else -> Color.WHITE
                }
            )
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()

        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager

        panel = TextView(this).apply {
            text = "QUOTEX SCANNER\n\nWAIT\nWaiting for signal..."
            textSize = 16f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.DKGRAY)
            setPadding(24, 18, 24, 18)
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= 26)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )

        params.gravity = Gravity.TOP or Gravity.END
        params.x = 15
        params.y = 150

        windowManager.addView(panel, params)

        val filter = android.content.IntentFilter(CaptureService.ACTION_RESULT)

        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(receiver, filter, RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(receiver, filter)
        }
    }

    override fun onDestroy() {
        try {
            unregisterReceiver(receiver)
            panel?.let { windowManager.removeView(it) }
        } catch (_: Exception) {
        }
        super.onDestroy()
    }
}
