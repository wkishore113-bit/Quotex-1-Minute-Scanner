package com.example.quotexscanner
import android.graphics.Bitmap
import android.graphics.Color
/** Experimental red/green pixel sampler; does not reliably reconstruct OHLC candles. */
object ChartVision {
    fun detect(b:Bitmap):List<Candle>{
        val left=(b.width*.12).toInt(); val right=(b.width*.94).toInt(); val top=(b.height*.12).toInt(); val bottom=(b.height*.78).toInt()
        val step=maxOf(3,b.width/150); val out=mutableListOf<Candle>(); var x=left
        while(x<right){
            var red=0;var green=0;var minY=bottom;var maxY=top
            for(y in top until bottom step 2){val c=b.getPixel(x,y);val r=Color.red(c);val g=Color.green(c);val bl=Color.blue(c)
                if(r>130 && r>g*1.25 && r>bl*1.15){red++;minY=minOf(minY,y);maxY=maxOf(maxY,y)}
                else if(g>105 && g>r*1.15 && g>bl*1.05){green++;minY=minOf(minY,y);maxY=maxOf(maxY,y)}
            }
            if(red+green>=2 && maxY>minY){val up=green>=red;val hi=(bottom-minY).toDouble();val lo=(bottom-maxY).toDouble();val mid=(hi+lo)/2;val body=maxOf(1.0,(maxY-minY)*.45);val o=if(up)mid-body/2 else mid+body/2;val cl=if(up)mid+body/2 else mid-body/2
                out+=Candle(o,maxOf(hi,o,cl),minOf(lo,o,cl),cl,up)}
            x+=step
        }
        return out.takeLast(120)
    }
}
