package com.example.quotexscanner
data class Candle(val open:Double,val high:Double,val low:Double,val close:Double,val bullish:Boolean)
data class ScanResult(val signal:String,val bullScore:Int,val bearScore:Int,val details:List<String>)
