package com.example.quotexscanner
import android.app.*
import android.content.*
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.util.DisplayMetrics
import android.view.WindowManager

class CaptureService:Service(){
    companion object{const val EXTRA_CODE="code";const val EXTRA_DATA="data";const val ACTION_RESULT="com.example.quotexscanner.RESULT";const val CHANNEL="capture"}
    private var projection:MediaProjection?=null;private var display:VirtualDisplay?=null;private var reader:ImageReader?=null;private var worker:HandlerThread?=null;private var handler:Handler?=null;private var last=0L
    override fun onBind(i:Intent?)=null
    override fun onStartCommand(i:Intent?,flags:Int,startId:Int):Int{
        val nm=getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if(Build.VERSION.SDK_INT>=26) nm.createNotificationChannel(NotificationChannel(CHANNEL,"Screen scanner",NotificationManager.IMPORTANCE_LOW))
        val note=if(Build.VERSION.SDK_INT>=26) Notification.Builder(this,CHANNEL).setContentTitle("Quotex scanner active").setContentText("Experimental screen analysis").setSmallIcon(android.R.drawable.ic_menu_search).build()
            else @Suppress("DEPRECATION") Notification.Builder(this).setContentTitle("Quotex scanner active").setSmallIcon(android.R.drawable.ic_menu_search).build()
        if(Build.VERSION.SDK_INT>=29) startForeground(7,note,android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION) else startForeground(7,note)
        val code=i?.getIntExtra(EXTRA_CODE,Activity.RESULT_CANCELED)?:Activity.RESULT_CANCELED
        val data=if(Build.VERSION.SDK_INT>=33)i?.getParcelableExtra(EXTRA_DATA,Intent::class.java) else @Suppress("DEPRECATION") i?.getParcelableExtra(EXTRA_DATA)
        if(code==Activity.RESULT_OK && data!=null) begin(code,data)
        return START_NOT_STICKY
    }
    private fun begin(code:Int,data:Intent){
        val mgr=getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager;projection=mgr.getMediaProjection(code,data)
        worker=HandlerThread("screen-scan").also{it.start()};handler=Handler(worker!!.looper)
        val dm=DisplayMetrics();@Suppress("DEPRECATION") (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(dm)
        reader=ImageReader.newInstance(dm.widthPixels,dm.heightPixels,PixelFormat.RGBA_8888,2)
        projection?.registerCallback(object:MediaProjection.Callback(){override fun onStop(){stopSelf()}},handler)
        display=projection?.createVirtualDisplay("QuotexScan",dm.widthPixels,dm.heightPixels,dm.densityDpi,DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,reader?.surface,null,handler)
        reader?.setOnImageAvailableListener({rdr->
            if(System.currentTimeMillis()-last<5000){rdr.acquireLatestImage()?.close();return@setOnImageAvailableListener};last=System.currentTimeMillis()
            val img=rdr.acquireLatestImage()?:return@setOnImageAvailableListener
            try{
                val p=img.planes[0];val pad=p.rowStride/p.pixelStride-img.width
                val wide=Bitmap.createBitmap(img.width+pad,img.height,Bitmap.Config.ARGB_8888);wide.copyPixelsFromBuffer(p.buffer)
                val bmp=Bitmap.createBitmap(wide,0,0,img.width,img.height);wide.recycle()
                val result=TechnicalAnalysis.analyze(ChartVision.detect(bmp));bmp.recycle()
                val out=Intent(ACTION_RESULT).setPackage(packageName).putExtra("signal",result.signal).putExtra("bull",result.bullScore).putExtra("bear",result.bearScore).putStringArrayListExtra("details",ArrayList(result.details));sendBroadcast(out)
            }catch(e:Exception){sendBroadcast(Intent(ACTION_RESULT).setPackage(packageName).putExtra("signal","WAIT").putExtra("bull",50).putExtra("bear",50).putStringArrayListExtra("details",arrayListOf("Screen parsing failed: ${e.message}")))}
            finally{img.close()}
        },handler)
    }
    override fun onDestroy(){reader?.close();display?.release();projection?.stop();worker?.quitSafely();super.onDestroy()}
}
