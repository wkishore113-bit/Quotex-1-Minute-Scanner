# Quotex 1-minute Android Scanner — experimental prototype

## Features in this starter source
- Android screen capture permission using MediaProjection
- Pair label selector for EUR/USD OTC and EUR/USD
- Experimental red/green pixel sampling from the visible screen
- EMA 9 / EMA 21 and RSI 14 calculations
- Basic candle-body and wick interpretation
- Rough liquidity sweep and 3-candle FVG heuristics
- CALL / PUT / WAIT signal display
- No account login, private API, or trade execution

## Critical limitations
This is **not a reliable prediction bot**. The pixel sampler does not reconstruct real OHLC candles. It can misread candles, chart themes, overlays, grid lines and scaling. Therefore EMA/RSI and pattern checks are based on synthetic approximations. The shown bullish/bearish percentages are heuristic rule scores, not calibrated probabilities or win rates. Order blocks and ZigZag are not properly implemented. Pair selection is only a label and the app cannot verify the actual pair/timeframe.

Use demo mode only. Do not use these signals to risk real funds. No method can know the next candle with certainty.

## Open and build
1. Extract the ZIP on a computer.
2. Install recent Android Studio and JDK 17.
3. Open the extracted project folder in Android Studio.
4. Allow Gradle sync; install Android SDK 35 if prompted.
5. Connect an Android phone with USB debugging, then press Run.

The project uses Android Gradle Plugin 8.7.3 and Kotlin 2.0.21. A Gradle wrapper is not bundled; Android Studio can generate/use a compatible Gradle 8.9 wrapper during sync.

## Test
1. Open Quotex and set EUR/USD OTC or EUR/USD on the 1-minute chart.
2. Open this scanner, choose the matching pair label, tap Start and approve screen capture.
3. Keep the chart visible and unobstructed. Capture behavior can vary by Android version/device.
4. Tap Stop to end scanning.

## Required engineering before any serious evaluation
Calibrate the chart crop for your exact Quotex UI and phone, detect candle bodies/wicks independently, map pixels to prices, verify pair/timeframe, implement robust swing/ZigZag and OB rules, then backtest on labelled historical data and calibrate scores out-of-sample. This source has not been validated on live Quotex charts or tested for profitability.
