
package com.example.quotexscanner

import android.graphics.Bitmap
import android.graphics.Color

object ChartVision {

    fun detect(b: Bitmap): List<Candle> {

        val left = (b.width * 0.12).toInt()
        val right = (b.width * 0.94).toInt()
        val top = (b.height * 0.12).toInt()
        val bottom = (b.height * 0.78).toInt()

        val step = maxOf(2, b.width / 300)
        val candles = mutableListOf<Candle>()

        var x = left

        while (x < right) {

            var red = 0
            var green = 0
            var minY = bottom
            var maxY = top

            for (y in top until bottom step 2) {

                val pixel = b.getPixel(x, y)

                val r = Color.red(pixel)
                val g = Color.green(pixel)
                val bl = Color.blue(pixel)

                val isRed = r > 120 && r > g * 1.25 &&
                        r > bl * 1.15

                val isGreen = g > 100 && g > r * 1.15 &&
                        g > bl * 1.05

                if (isRed || isGreen) {

                    if (isRed) red++
                    if (isGreen) green++

                    minY = minOf(minY, y)
                    maxY = maxOf(maxY, y)
                }
            }

            if (red + green >= 3 && maxY > minY) {

                val bullish = green > red

                val high = (bottom - minY).toDouble()
                val low = (bottom - maxY).toDouble()

                val range = high - low
                val body = maxOf(1.0, range * 0.45)
                val mid = (high + low) / 2.0

                val open = if (bullish) mid - body / 2 else mid + body / 2
                val close = if (bullish) mid + body / 2 else mid - body / 2

                candles.add(
                    Candle(
                        open = open,
                        high = maxOf(high, open, close),
                        low = minOf(low, open, close),
                        close = close,
                        bullish = bullish
                    )
                )
            }

            x += step
        }

        return candles.takeLast(120)
    }
}
