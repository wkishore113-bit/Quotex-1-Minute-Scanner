
package com.example.quotexscanner

import kotlin.math.abs
import kotlin.math.max

object TechnicalAnalysis {

    fun analyze(c: List<Candle>): ScanResult {

        if (c.size < 30) {
            return ScanResult(
                "WAIT", 50, 50,
                listOf("Need at least 30 detected candles.")
            )
        }

        // Use earlier samples rather than the latest detected sample.
        val completed = c.dropLast(1)

        if (completed.size < 29) {
            return ScanResult("WAIT", 50, 50, listOf("Waiting for more candles."))
        }

        val closes = completed.map { it.close }

        val e9 = ema(closes, 9)
        val e21 = ema(closes, 21)
        val r = rsi(closes, 14)

        var bull = 0
        var bear = 0
        val notes = mutableListOf<String>()

        if (e9 > e21) {
            bull += 2
            notes.add("EMA trend: bullish")
        } else if (e9 < e21) {
            bear += 2
            notes.add("EMA trend: bearish")
        }

        if (r >= 55) {
            bull += 2
            notes.add("RSI bullish: ${r.toInt()}")
        } else if (r <= 45) {
            bear += 2
            notes.add("RSI bearish: ${r.toInt()}")
        } else {
            notes.add("RSI neutral: ${r.toInt()}")
        }

        val last = completed.last()
        val previous = completed[completed.lastIndex - 1]

        val range = max(0.000001, last.high - last.low)
        val body = abs(last.close - last.open)

        if (last.bullish && body / range >= 0.55) {
            bull++
            notes.add("Bullish candle confirmation")
        }

        if (!last.bullish && body / range >= 0.55) {
            bear++
            notes.add("Bearish candle confirmation")
        }

        // Liquidity sweep approximation
        val recent = completed.takeLast(12)
        val prior = recent.dropLast(1)

        val priorHigh = prior.maxOf { it.high }
        val priorLow = prior.minOf { it.low }

        if (last.high > priorHigh && last.close < priorHigh) {
            bear += 2
            notes.add("Possible buy-side liquidity sweep")
        }

        if (last.low < priorLow && last.close > priorLow) {
            bull += 2
            notes.add("Possible sell-side liquidity sweep")
        }

        // Three-candle FVG approximation
        val n = completed.lastIndex

        if (completed[n].low > completed[n - 2].high) {
            bull++
            notes.add("Possible bullish FVG")
        }

        if (completed[n - 2].low > completed[n].high) {
            bear++
            notes.add("Possible bearish FVG")
        }

        // Avoid signals when the previous two candle directions conflict.
        if (last.bullish != previous.bullish) {
            notes.add("Mixed candle directions: caution")
        }

        val total = max(1, bull + bear)
        val bullScore = (bull * 100.0 / total).toInt()
        val bearScore = 100 - bullScore

        val signal = when {
            bull >= bear + 3 && bullScore >= 65 -> "CALL"
            bear >= bull + 3 && bearScore >= 65 -> "PUT"
            else -> "WAIT"
        }

        notes.add("Bullish rule score: $bullScore%")
        notes.add("Bearish rule score: $bearScore%")
        notes.add("Scores are heuristic, not actual probabilities.")
        notes.add("Screen-based candles are experimental; OB and ZigZag are not reliably detected.")

        return ScanResult(signal, bullScore, bearScore, notes)
    }

    private fun ema(values: List<Double>, period: Int): Double {
        val k = 2.0 / (period + 1)
        var result = values.take(period).average()

        for (value in values.drop(period)) {
            result = value * k + result * (1 - k)
        }

        return result
    }

    private fun rsi(values: List<Double>, period: Int): Double {
        val changes = values.zipWithNext { a, b -> b - a }.takeLast(period)

        val gains = changes.filter { it > 0 }.sum() / period
        val losses = -changes.filter { it < 0 }.sum() / period

        if (losses == 0.0) return 100.0

        val rs = gains / losses
        return 100 - (100 / (1 + rs))
    }
}
